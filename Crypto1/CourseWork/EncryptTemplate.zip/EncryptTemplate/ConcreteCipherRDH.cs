using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;
using CourseWork.LOKI97.Algorithm.CipherAlgorithm;
using CourseWork.Stuff;

namespace CourseWork.EncryptTemplate
{
    public class ConcreteCipherRDH : CipherTemplate
    {
        private ICipherAlgorithm _cipherAlgorithm;
        private Byte[] _valueForHash;
        
        public ConcreteCipherRDH(ICipherAlgorithm cipherAlgorithm, params Object[] list)
        {
            _valueForHash = (Byte[])list.First();
            _cipherAlgorithm = cipherAlgorithm;
        }
        
        public override Byte[] EncryptFirstBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            var outputBuffer = new List<Byte[]>();
            var initial = Utils.GetInitial(iv, _cipherAlgorithm.GetBlockSize());

            var encryptInitial = _cipherAlgorithm.BlockEncrypt(initial, 0);
            var hashAlgorithm = MD5.Create();
            var encryptedHash =
                _cipherAlgorithm.BlockEncrypt(Utils.Xor(initial, hashAlgorithm.ComputeHash(_valueForHash)), 0);
            var firstBlock =
                _cipherAlgorithm.BlockEncrypt(
                    Utils.Xor(
                        Utils.GetInitial(iv, _cipherAlgorithm.GetBlockSize()), 
                        blocksList.First()), 0);

            blocksList.Remove(blocksList.First());
            outputBuffer.Add(encryptInitial);
            outputBuffer.Add(encryptedHash);
            outputBuffer.Add(firstBlock);
            outputBuffer.Add(EncryptBlock(blocksList, ref iv));

            return outputBuffer.SelectMany(x => x).ToArray();
        }

        public override Byte[] EncryptLastBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }

        public override Byte[] EncryptOtherBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }

        protected override Byte[] EncryptBlock(List<Byte[]> blocksList, ref Byte[] iv)
        {
            var blockSize = _cipherAlgorithm.GetBlockSize();
            var outputBuffer = Enumerable.Repeat(default(Byte[]), blocksList.Count).ToList();
            var counterList = GetCounterListV2(iv, blocksList.Count, blockSize);
            
            Array.Copy(sourceArray: counterList.Last(),
                sourceIndex: 0,
                destinationArray: iv,
                destinationIndex: 0,
                length: counterList.Last().Length);
            
            Parallel.For(0, outputBuffer.Count, i =>
                    
                outputBuffer[i] = _cipherAlgorithm.BlockEncrypt(Utils.Xor(counterList[i], blocksList[i]), 0) 
            );
            
            return outputBuffer.SelectMany(x => x).ToArray();
        }

        public override Byte[] DecryptFirstBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            if (Utils.IsWrongInit(_cipherAlgorithm, iv, _valueForHash, blocksList[1]))
            {
                throw new ArgumentException();
            }

            var outputBuffer = new List<Byte[]>();
            var firstBlock = Utils.Xor(Utils.GetInitial(iv, _cipherAlgorithm.GetBlockSize()), _cipherAlgorithm.BlockDecrypt(blocksList[2], 0));
            blocksList.RemoveRange(0, 3);
            outputBuffer.Add(firstBlock);
            outputBuffer.Add(DecryptBlock(blocksList, ref iv));

            return outputBuffer.SelectMany(x => x).ToArray();
        }

        public override Byte[] DecryptLastBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return DecryptBlock(blocksList, ref iv);
        }

        public override Byte[] DecryptOtherBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return DecryptBlock(blocksList, ref iv);
        }

        protected override Byte[] DecryptBlock(List<Byte[]> blocksList, ref Byte[] iv)
        {
            var outputBuffer = Enumerable.Repeat(default(Byte[]), blocksList.Count).ToList();
            var counterList = GetCounterListV2(iv, blocksList.Count, _cipherAlgorithm.GetBlockSize());
            
            Array.Copy(sourceArray: counterList.Last(),
                sourceIndex: 0,
                destinationArray: iv,
                destinationIndex: 0,
                length: counterList.Last().Length);

            Parallel.For(0, blocksList.Count, i =>
                    
                outputBuffer[i] = Utils.Xor(_cipherAlgorithm.BlockDecrypt(blocksList[i], 0), counterList[i])
            );

            return outputBuffer.SelectMany(x => x).ToArray();
        }
        
        public static List<Byte[]> GetCounterListV2(Byte[] iv, Int32 size, Int32 blockSize)
        {
            var delta = Utils.GetDeltaAsBiginteger(iv, blockSize);
            var initializationVector = Utils.GetInitialAsBiginteger(iv, blockSize);
            var counterList = Enumerable.Repeat(default(Byte[]), size).ToList();
            
            for (var count = 0; count < counterList.Count; count++)
            {
                initializationVector += delta;
                counterList[count] = initializationVector.ToByteArray();
            }

            return counterList;
        }
    }
}