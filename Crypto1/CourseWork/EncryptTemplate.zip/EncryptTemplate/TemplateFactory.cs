using System;
using System.Text;
using CourseWork.LOKI97.Algorithm.CipherAlgorithm;
using CourseWork.LOKI97.AlgorithmService.Modes;

namespace CourseWork.EncryptTemplate
{
    public class TemplateFactory
    {
        public CipherTemplate CreateEncryptionMode(ICipherAlgorithm cipherAlgorithm, EncryptionMode encryptionMode, params Object[] list)
        {
            return encryptionMode switch
            {
                EncryptionMode.ECB => new ConcreteCipherECB(cipherAlgorithm),
                EncryptionMode.CBC => new ConcreteCipherCBC(cipherAlgorithm),
                EncryptionMode.CFB => new ConcreteCipherCFB(cipherAlgorithm),
                EncryptionMode.OFB => new ConcreteCipherOFB(cipherAlgorithm),
                EncryptionMode.CTR => new ConcreteCipherCTR(cipherAlgorithm),
                EncryptionMode.RD => new ConcreteCipherRD(cipherAlgorithm),
                EncryptionMode.RDH => new ConcreteCipherRDH(cipherAlgorithm, /*(Byte[])list.First()*/ Encoding.Default.GetBytes("list.First() as Byte[]")),
                _ => throw new ArgumentException("Unexpected value: " + encryptionMode)
            };
        }
    }
}