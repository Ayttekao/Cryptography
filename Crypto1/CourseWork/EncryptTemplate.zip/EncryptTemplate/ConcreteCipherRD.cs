using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CourseWork.LOKI97.Algorithm.CipherAlgorithm;
using CourseWork.Stuff;

namespace CourseWork.EncryptTemplate
{
    public class ConcreteCipherRD : CipherTemplate
    {
        private ICipherAlgorithm _cipherAlgorithm;
        
        public ConcreteCipherRD(ICipherAlgorithm cipherAlgorithm)
        {
            _cipherAlgorithm = cipherAlgorithm;
        }
        
        public override Byte[] EncryptFirstBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            var outputBuffer = new List<Byte[]>();
            var initial =
                _cipherAlgorithm.BlockEncrypt(Utils.GetInitial(iv, _cipherAlgorithm.GetBlockSize()), 0);
            var firstBlock =
                _cipherAlgorithm.BlockEncrypt(
                    Utils.Xor(
                        Utils.GetInitial(iv, _cipherAlgorithm.GetBlockSize()), 
                        blocksList.First()), 0);
            blocksList.Remove(blocksList.First());
            
            outputBuffer.Add(initial);
            outputBuffer.Add(firstBlock);
            outputBuffer.Add(EncryptBlock(blocksList, ref iv));
            
            return outputBuffer.SelectMany(x => x).ToArray();
        }

        public override Byte[] EncryptLastBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }

        public override Byte[] EncryptOtherBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }

        protected override Byte[] EncryptBlock(List<Byte[]> blocksList, ref Byte[] iv)
        {
            var blockSize = _cipherAlgorithm.GetBlockSize();
            var outputBuffer = Enumerable.Repeat(default(Byte[]), blocksList.Count).ToList();
            var counterList = GetCounterListV2(iv, blocksList.Count, blockSize);
            
            Array.Copy(sourceArray: counterList.Last(),
                sourceIndex: 0,
                destinationArray: iv,
                destinationIndex: 0,
                length: counterList.Last().Length);

            Parallel.For(0, blocksList.Count, count =>
                    
                outputBuffer[count] = _cipherAlgorithm.BlockEncrypt(Utils.Xor(counterList[count], blocksList[count]), 0) 
            );
            
            return outputBuffer.SelectMany(x => x).ToArray();
        }

        public override Byte[] DecryptFirstBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            var outputBuffer = new List<Byte[]>();
            var initial =
                _cipherAlgorithm.BlockDecrypt(blocksList.First().ToArray(), 0);
            blocksList.Remove(blocksList.First());
            var firstBlock = Utils.Xor(initial, _cipherAlgorithm.BlockDecrypt(blocksList.First(), 0));
            blocksList.Remove(blocksList.First());
            
            outputBuffer.Add(firstBlock);
            outputBuffer.Add(DecryptBlock(blocksList, ref iv));
            
            return outputBuffer.SelectMany(x => x).ToArray();
        }

        public override Byte[] DecryptLastBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return DecryptBlock(blocksList, ref iv);
        }

        public override Byte[] DecryptOtherBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return DecryptBlock(blocksList, ref iv);
        }

        protected override Byte[] DecryptBlock(List<Byte[]> blocksList, ref Byte[] iv)
        {
            var outputBuffer = Enumerable.Repeat(default(Byte[]), blocksList.Count).ToList();
            var counterList = GetCounterListV2(iv, blocksList.Count, _cipherAlgorithm.GetBlockSize());
            
            Array.Copy(sourceArray: counterList.Last(),
                sourceIndex: 0,
                destinationArray: iv,
                destinationIndex: 0,
                length: counterList.Last().Length);

            Parallel.For(0, blocksList.Count, count =>
                    
                outputBuffer[count] = Utils.Xor(_cipherAlgorithm.BlockDecrypt(blocksList[count], 0), counterList[count]) 
            );
            
            return outputBuffer.SelectMany(x => x).ToArray();
        }
        
        public static List<Byte[]> GetCounterListV2(Byte[] iv, Int32 size, Int32 blockSize)
        {
            var delta = Utils.GetDeltaAsBiginteger(iv, blockSize);
            var initializationVector = Utils.GetInitialAsBiginteger(iv, blockSize);
            var counterList = Enumerable.Repeat(default(Byte[]), size).ToList();
            
            for (var count = 0; count < counterList.Count; count++)
            {
                initializationVector += delta;
                counterList[count] = initializationVector.ToByteArray();
            }

            return counterList;
        }
    }
}