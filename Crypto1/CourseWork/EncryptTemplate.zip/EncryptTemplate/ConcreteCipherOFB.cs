using System;
using System.Collections.Generic;
using CourseWork.LOKI97.Algorithm.CipherAlgorithm;
using CourseWork.Stuff;

namespace CourseWork.EncryptTemplate
{
    public class ConcreteCipherOFB : CipherTemplate
    {
        private ICipherAlgorithm _cipherAlgorithm;
        
        public ConcreteCipherOFB(ICipherAlgorithm cipherAlgorithm)
        {
            _cipherAlgorithm = cipherAlgorithm;
        }
        
        public override Byte[] EncryptFirstBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }

        public override Byte[] EncryptLastBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }

        public override Byte[] EncryptOtherBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }

        protected override Byte[] EncryptBlock(List<Byte[]> blocksList, ref Byte[] iv)
        {
            var blockSize = _cipherAlgorithm.GetBlockSize();
            var outputBuffer = new Byte[blocksList.Count * blockSize];
            var step = 0;

            foreach (var block in blocksList)
            {
                iv = _cipherAlgorithm.BlockEncrypt(iv, 0);
                var res = Utils.Xor(iv, block);
                Array.Copy(res, 0, outputBuffer, step++ * blockSize, blockSize);
            }

            return outputBuffer;
        }

        public override Byte[] DecryptFirstBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }

        public override Byte[] DecryptLastBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }

        public override Byte[] DecryptOtherBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }

        protected override Byte[] DecryptBlock(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }
    }
}