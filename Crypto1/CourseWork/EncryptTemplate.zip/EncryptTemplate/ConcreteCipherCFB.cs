using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CourseWork.LOKI97.Algorithm.CipherAlgorithm;
using CourseWork.Stuff;

namespace CourseWork.EncryptTemplate
{
    public class ConcreteCipherCFB : CipherTemplate
    {
        private ICipherAlgorithm _cipherAlgorithm;
        
        public ConcreteCipherCFB(ICipherAlgorithm cipherAlgorithm)
        {
            _cipherAlgorithm = cipherAlgorithm;
        }
        
        public override Byte[] EncryptFirstBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }

        public override Byte[] EncryptLastBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }

        public override Byte[] EncryptOtherBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }

        protected override Byte[] EncryptBlock(List<Byte[]> blocksList, ref Byte[] iv)
        {
            var blockSize = _cipherAlgorithm.GetBlockSize();
            var outputBuffer = new Byte[blocksList.Count * blockSize];

            var step = 0;

            foreach (var block in blocksList)
            {
                iv = _cipherAlgorithm.BlockEncrypt(iv, 0);
                iv = Utils.Xor(iv, block);

                Array.Copy(iv, 0, outputBuffer, (step++) * blockSize, blockSize);
            }

            return outputBuffer;
        }

        public override Byte[] DecryptFirstBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return DecryptBlock(blocksList, ref iv);
        }

        public override Byte[] DecryptLastBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return DecryptBlock(blocksList, ref iv);
        }

        public override Byte[] DecryptOtherBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return DecryptBlock(blocksList, ref iv);
        }

        protected override Byte[] DecryptBlock(List<Byte[]> blocksList, ref Byte[] iv)
        {
            blocksList.Insert(0, iv);
            var outputBuffer = Enumerable.Repeat(default(Byte[]), blocksList.Count - 1).ToList();
            var inputBuffer = new List<Byte[]>(blocksList);

            Parallel.For(0, outputBuffer.Count, index =>
                    
                outputBuffer[index] = Utils.Xor(_cipherAlgorithm.BlockEncrypt(inputBuffer[index], 0), inputBuffer[index + 1])
            );

            iv = blocksList.Last();
            return outputBuffer.SelectMany(x => x).ToArray();
        }
    }
}