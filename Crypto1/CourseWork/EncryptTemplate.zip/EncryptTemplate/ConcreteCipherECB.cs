using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CourseWork.LOKI97.Algorithm.CipherAlgorithm;

namespace CourseWork.EncryptTemplate
{
    public class ConcreteCipherECB : CipherTemplate
    {
        private ICipherAlgorithm _cipherAlgorithm;
        
        public ConcreteCipherECB(ICipherAlgorithm cipherAlgorithm)
        {
            _cipherAlgorithm = cipherAlgorithm;
        }

        public override Byte[] EncryptFirstBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }

        public override Byte[] EncryptLastBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }

        public override Byte[] EncryptOtherBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return EncryptBlock(blocksList, ref iv);
        }

        protected override Byte[] EncryptBlock(List<Byte[]> blocksList, ref Byte[] iv)
        {
            var outputBuffer = Enumerable.Repeat(default(Byte[]), blocksList.Count).ToList();

            Parallel.For(0, outputBuffer.Count, counter =>
                
                outputBuffer[counter] = _cipherAlgorithm.BlockEncrypt(blocksList[counter], 0)
            );

            return outputBuffer.SelectMany(x => x).ToArray();
        }

        public override Byte[] DecryptFirstBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return DecryptBlock(blocksList, ref iv);
        }

        public override Byte[] DecryptLastBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return DecryptBlock(blocksList, ref iv);
        }

        public override Byte[] DecryptOtherBytes(List<Byte[]> blocksList, ref Byte[] iv)
        {
            return DecryptBlock(blocksList, ref iv);
        }

        protected override Byte[] DecryptBlock(List<Byte[]> blocksList, ref Byte[] iv)
        {
            var outputBuffer = Enumerable.Repeat(default(Byte[]), blocksList.Count).ToList();

            Parallel.For(0, outputBuffer.Count, counter =>
                
                outputBuffer[counter] = _cipherAlgorithm.BlockDecrypt(blocksList[counter], 0)
            );

            return outputBuffer.SelectMany(x => x).ToArray();
        }
    }
}