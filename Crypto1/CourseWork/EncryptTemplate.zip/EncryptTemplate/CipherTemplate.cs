using System;
using System.Collections.Generic;

namespace CourseWork.EncryptTemplate
{
    public abstract class CipherTemplate
    {
        public abstract Byte[] EncryptFirstBytes(List<Byte[]> blocksList, ref Byte[] iv);
        
        public abstract Byte[] EncryptLastBytes(List<Byte[]> blocksList, ref Byte[] iv);
        public abstract Byte[] EncryptOtherBytes(List<Byte[]> blocksList, ref Byte[] iv);
        protected abstract Byte[] EncryptBlock(List<Byte[]> blocksList, ref Byte[] iv);
        
        public abstract Byte[] DecryptFirstBytes(List<Byte[]> blocksList, ref Byte[] iv);
        
        public abstract Byte[] DecryptLastBytes(List<Byte[]> blocksList, ref Byte[] iv);
        public abstract Byte[] DecryptOtherBytes(List<Byte[]> blocksList, ref Byte[] iv);
        protected abstract Byte[] DecryptBlock(List<Byte[]> blocksList, ref Byte[] iv);
    }
}